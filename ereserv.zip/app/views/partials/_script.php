<!-- jQuery -->
<script src="<?=ASSETS;?>LTE/plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?=ASSETS;?>LTE/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?=ASSETS;?>LTE/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="<?=ASSETS;?>LTE/plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="<?=ASSETS;?>LTE/plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="<?=ASSETS;?>LTE/plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="<?=ASSETS;?>LTE/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="<?=ASSETS;?>LTE/plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="<?=ASSETS;?>LTE/plugins/moment/moment.min.js"></script>
<script src="<?=ASSETS;?>LTE/plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?=ASSETS;?>LTE/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="<?=ASSETS;?>LTE/plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?=ASSETS;?>LTE/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?=ASSETS;?>LTE/dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<!-- <script src="<?=ASSETS;?>LTE/dist/js/pages/dashboard.js"></script> -->
<!-- AdminLTE for demo purposes --> 
<script src="<?=ASSETS;?>LTE/dist/js/demo.js"></script>
<!-- Select2 -->
<script src="<?=ASSETS;?>LTE/plugins/select2/js/select2.full.min.js"></script>
<!-- Bootstrap Switch -->
<script src="<?=ASSETS;?>LTE/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<script src="<?=ASSETS;?>LTE/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<!-- bs-custom-file-input -->
<script src="<?=ASSETS;?>LTE/plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>

<!-- DataTables -->
<script src="<?=ASSETS;?>LTE/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?=ASSETS;?>LTE/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?=ASSETS;?>LTE/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?=ASSETS;?>LTE/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>

<!-- html2pdf -->
<script src="<?=ASSETS;?>LTE/plugins/html2pdf.bundle.js"></script>
<!-- printThis -->
<script src="<?=ASSETS;?>LTE/plugins/printThis.js"></script>
<!-- sweetalert2 -->
<script src="<?=ASSETS;?>LTE/package/dist/sweetalert2.all.min.js"></script>

<!-- <script src="<?= ASSETS ?>LTE/plugins/xlsx/xlsx.full.min.js"></script>
<script src="<?= ASSETS ?>LTE/plugins/xlsx/FileSaver.js"></script>
<script src="<?= ASSETS ?>LTE/plugins/xlsx/jhxlsx.js"></script> -->