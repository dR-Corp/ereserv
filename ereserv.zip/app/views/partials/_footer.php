<footer class="main-footer text-center text-sm">
    <strong style="color: #044687;">&copy; <a href="http://eReserv.bj" style="color: #044687;">eReserv.bj</a> 2024. Tous les droits réservés.</strong>
</footer>